package com.cg.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class EducationalPage {

	private WebDriver driver;
	
	private WebElement title;

	@FindBy(how = How.XPATH, using = "/html/body/h4")
	@CacheLookup
	private WebElement heading;
	
	@FindBy(how = How.NAME,using = "graduation")
	@CacheLookup
	private WebElement graduation;
	
	@FindBy(how = How.ID,using = "txtPercentage")
	@CacheLookup
	private WebElement percentage;
	
	@FindBy(how = How.NAME,using = "passingYear")
	@CacheLookup
	private WebElement passingYear;
	
	@FindBy(how = How.NAME,using = "projectName")
	@CacheLookup
	private WebElement projectName;
	
	@FindBy(how = How.NAME,using = "technologies")
	@CacheLookup
	private WebElement technologyUsed;
	
	@FindBy(how = How.NAME,using = "otherTechnologies")
	@CacheLookup
	private WebElement otherTechnology;
	
	@FindBy(how = How.ID,using = "btnRegister")
	private WebElement registerMe;
	
	public String titlename() {
		return driver.getTitle();
	}

	public String headingname() {
		return this.heading.getText();
	}
	
	public void registerbtnclick() {
		registerMe.click();
	}

	public EducationalPage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EducationalPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public WebElement getGraduation() {
		return graduation;
	}

	public void setGraduation(String graduation) {
		this.graduation.sendKeys(graduation);
	}

	public WebElement getPercentage() {
		return percentage;
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public WebElement getPassingYear() {
		return passingYear;
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public WebElement getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public WebElement getTechnologyUsed() {
		return technologyUsed;
	}

	public void setTechnologyUsed(String technologyUsed) {
		this.technologyUsed.sendKeys(technologyUsed);
	}

	public WebElement getOtherTechnology() {
		return otherTechnology;
	}

	public void setOtherTechnology(String otherTechnology) {
		this.otherTechnology.sendKeys(otherTechnology);
	}
	
	
}
