package com.cg.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PersonalPage {

	private WebDriver driver;

	private WebElement title;

	@FindBy(how = How.XPATH, using = "/html/body/h4")
	@CacheLookup
	private WebElement heading;

	@FindBy(how = How.ID, using = "txtFirstName")
	@CacheLookup
	private WebElement firstName;

	@FindBy(how = How.ID, using = "txtLastName")
	@CacheLookup
	private WebElement lastName;

	@FindBy(how = How.NAME, using = "Email")
	@CacheLookup
	private WebElement email;

	@FindBy(how = How.ID, using = "txtPhone")
	@CacheLookup
	private WebElement contactNo;

	@FindBy(how = How.NAME, using = "address1")
	@CacheLookup
	private WebElement addressline1;

	@FindBy(how = How.NAME, using = "address2")
	@CacheLookup
	private WebElement addressline2;

	@FindBy(how = How.NAME, using = "city")
	@CacheLookup
	private WebElement city;

	@FindBy(how = How.NAME, using = "state")
	@CacheLookup
	private WebElement state;

	@FindBy(how = How.LINK_TEXT, using = " Next ")
	@CacheLookup
	private WebElement nextlinkclick;

	public String titlename() {
		return driver.getTitle();
	}

	public String headingname() {
		return this.heading.getText();
	}

	public void nextlinkclick() {
		nextlinkclick.click();
	}

	public PersonalPage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PersonalPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo.sendKeys(contactNo);
	}

	public WebElement getAddressline1() {
		return addressline1;
	}

	public void setAddressline1(String addressline1) {
		this.addressline1.sendKeys(addressline1);
	}

	public WebElement getAddressline2() {
		return addressline2;
	}

	public void setAddressline2(String addressline2) {
		this.addressline2.sendKeys(addressline2);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

}
