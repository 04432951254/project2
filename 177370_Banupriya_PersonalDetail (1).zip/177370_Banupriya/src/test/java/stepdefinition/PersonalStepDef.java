package stepdefinition;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowserFactory;
import com.cg.page.PersonalPage;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDef {

	static WebDriver driver;
	PersonalPage personalPage;

	@Before
	public void start() {
		driver = BrowserFactory.startBrowser("chrome",
				"D:\\Users\\banuprr\\Selenium\\177370_Banupriya\\src\\test\\java\\html\\PersonalDetails.html");
	}

	@After
	public void tearDown() {
		driver.close();
	}

	@Given("^user is in the personal details page$")
	public void user_is_in_the_personal_details_page() throws Throwable {
		personalPage = PageFactory.initElements(driver, PersonalPage.class);
	}

	@Then("^verify the title of the page$")
	public void verify_the_title_of_the_page() throws Throwable {
		assertEquals("Personal Details", personalPage.titlename());
		if (personalPage.titlename().equals("Personal Details")) {
			System.out.println("Title matched");
		} else {
			System.out.println("Title not matched");
		}
	}

	@Then("^verify the heading of the page$")
	public void verify_the_heading_of_the_page() throws Throwable {
		assertEquals("Step 1: Personal Details", personalPage.headingname());
		if (personalPage.headingname().equals("Step 1: Personal Details")) {
			System.out.println("Heading matched");
		} else {
			System.out.println("Heading not matched");
		}
	}

	@When("^user leaves first name empty$")
	public void user_leaves_first_name_empty() throws Throwable {
		personalPage.setFirstName("banupriya");
	}

	@Then("^display first name alert message$")
	public void display_first_name_alert_message() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			Thread.sleep(1000);
			String msg = alt.getText();
			assertEquals("Please fill the First Name", msg);
			if (msg.equals("Please fill the First Name")) {
				System.out.println("The text msg on alert box is " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@When("^user leaves last name empty$")
	public void user_leaves_last_name_empty() throws Throwable {
		personalPage.setLastName("raju");
	}

	@Then("^display last name alert message$")
	public void display_last_name_alert_message() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Please fill the Last Name", msg);
			if (msg.equals("Please fill the Last Name")) {
				System.out.println("The text msg on alert box is " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email(DataTable arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		// For automatic transformation, change DataTable to one of
		// List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		// E,K,V must be a scalar (String, Integer, Date, enum etc)
		try {
			List<String> emailList = arg1.asList(String.class);
			personalPage.setFirstName("banupriya");
			personalPage.setLastName("raju");
			for (String email : emailList) {
				personalPage.getEmail().clear();
				personalPage.setEmail(email);
				if (Pattern.matches("/[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$/", email)) {
					System.out.println("Valid Email Id: " + email);
				} else {
					System.out.println("Pattern not matching, Invalid email id ");
				}
			}
			personalPage.setContactNo("9003259660");
			personalPage.setAddressline1("tambaram");
			personalPage.setAddressline2("medavakkam");
			personalPage.setCity("Chennai");
			personalPage.setState("Tamilnadu");
			personalPage.nextlinkclick();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Then("^display invalid email alert message$")
	public void display_invalid_email_alert_message() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Please enter valid Email Id.", msg);
			if (msg.equals("Please enter valid Email Id.")) {
				System.out.println("The text msg on alert box is " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@When("^user leaves contactNo empty$")
	public void user_leaves_contactNo_empty() throws Throwable {
		personalPage.setContactNo("");
	}

	@Then("^display contactNo alert message$")
	public void display_contactNo_alert_message() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Please fill the Contact No.", msg);
			if (msg.equals("Please fill the Contact No.")) {
				System.out.println("The text msg on alert box is " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@When("^user enters invalid contactNo$")
	public void user_enters_invalid_contactNo(DataTable arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		// For automatic transformation, change DataTable to one of
		// List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		// E,K,V must be a scalar (String, Integer, Date, enum etc)

	}

	@Then("^display invalid contactNo alert message$")
	public void display_invalid_contactNo_alert_message() throws Throwable {

	}

	@When("^user leaves addressline(\\d+) empty$")
	public void user_leaves_addressline_empty(int arg1) throws Throwable {
		personalPage.setAddressline1("");
	}

	@Then("^display addressline(\\d+) alert message$")
	public void display_addressline_alert_message(int arg1) throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Please fill the address line 1", msg);
			if (msg.equals("Please fill the address line 1")) {
				System.out.println("The text msg on alert box is " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@When("^user leaves addressLine(\\d+) empty$")
	public void user_leaves_addressLine_empty(int arg1) throws Throwable {
		personalPage.setAddressline2("");
	}

	@Then("^display addressLine(\\d+) alert message$")
	public void display_addressLine_alert_message(int arg1) throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Please fill the address line 2", msg);
			if (msg.equals("Please fill the address line 2")) {
				System.out.println("The text msg on alert box is " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@When("^user leaves city empty$")
	public void user_leaves_city_empty() throws Throwable {
		personalPage.setCity("");
	}

	@Then("^display city alert message$")
	public void display_city_alert_message() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Please select city", msg);
			if (msg.equals("Please select city")) {
				System.out.println("The text msg on alert box is " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@When("^user leaves state empty$")
	public void user_leaves_state_empty() throws Throwable {
		personalPage.setState("");
	}

	@Then("^display state alert message$")
	public void display_state_alert_message() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Please select state", msg);
			if (msg.equals("Please select state")) {
				System.out.println("The text msg on alert box is " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@When("^user enters valid credentials and clicks next$")
	public void user_enters_valid_credentials_and_clicks_next() throws Throwable {
		try {
			personalPage.setFirstName("banupriya");
			personalPage.setLastName("raju");
			personalPage.setEmail("banu@gmail.com");
			personalPage.setContactNo("9003259660");
			personalPage.setAddressline1("tambaram");
			personalPage.setAddressline2("medavakkam");
			personalPage.setCity("chennai");
			personalPage.setState("tamilnadu");
			personalPage.nextlinkclick();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Then("^navigate to eduactional details page$")
	public void navigate_to_eduactional_details_page() throws Throwable {
		System.out.println("Navigated to next page");
		
		/*
		 * driver.navigate() .to(
		 * "D:\\Users\\banuprr\\Selenium\\177370_Banupriya\\src\\test\\java\\html\\EducationalDetails.html"
		 * );
		 */
	}

}
